<?php
declare(strict_types=1);
// Uygulama içi güncellemenin birkaç saniyesinde (dosyalar değişirken) sayfa kendiliğinden yeniden dener
$nmUp = @file_get_contents(__DIR__ . '/data/.guncelleniyor');
if ($nmUp !== false && ($nmUpD = json_decode($nmUp, true)) && (int)($nmUpD['until'] ?? 0) > time() && ($nmUpD['kind'] ?? '') === 'auto') {
    http_response_code(503);
    header('Retry-After: 3');
    header('Cache-Control: no-store');
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="refresh" content="3"><title>dupcii</title>'
        . '<style>body{margin:0;display:grid;place-items:center;min-height:100vh;font-family:system-ui,sans-serif;background:#f6f8f9;color:#0f1b21}div{text-align:center;padding:24px}p{color:#5c6b73}</style></head>'
        . '<body><div><h2>Site güncelleniyor</h2><p>Birkaç saniye içinde kendiliğinden açılacak.</p></div></body></html>';
    exit;
}
require __DIR__ . '/inc/bootstrap.php';
nm_session();
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header("Content-Security-Policy: default-src 'self'; script-src 'self' https://accounts.google.com/gsi/client; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://accounts.google.com/gsi/style; font-src https://fonts.gstatic.com; img-src 'self' data: blob:; media-src 'self' blob:; frame-src 'self' https://accounts.google.com/gsi/ https://www.paytr.com" . (defined('NM_PAY_PAYTR_BASE') && NM_PAY_PAYTR_BASE ? ' ' . preg_replace('#^(https?://[^/]+).*#', '$1', (string)NM_PAY_PAYTR_BASE) : '') . "; connect-src 'self' https://accounts.google.com/gsi/; worker-src 'self' blob:; object-src 'none'; base-uri 'self'; frame-ancestors 'self'; form-action 'self' https://accounts.google.com");
$v = NM_VERSION;
// Yöneticinin yüklediği favicon ve uygulama simgesi (yoksa varsayılan dupcii simgesi)
$bv = fn(string $k) => (string)setting('brand_' . $k, '');
$favicon = $bv('icon') !== '' ? 'api.php?action=brand&f=icon&v=' . substr(md5($bv('icon')), 0, 10) : 'assets/icon.svg';
$favType = ['svg' => 'image/svg+xml', 'png' => 'image/png', 'ico' => 'image/x-icon', 'jpg' => 'image/jpeg', 'webp' => 'image/webp'][strtolower(pathinfo($bv('icon') ?: 'x.svg', PATHINFO_EXTENSION))] ?? 'image/png';
$touch = $bv('icon192') !== '' ? 'api.php?action=brand&f=icon192&v=' . substr(md5($bv('icon192')), 0, 10) : 'assets/icon-192.png';
// Bağlantı önizlemesi: birim belliyse birim adı, değilse dupcii
$org = nm_tenant_hinted() ? trim((string)setting('org_name', '')) : '';
if ($org === 'Klinik Portalı') $org = '';
$ogTitle = $org !== '' ? $org . ' · dupcii' : 'dupcii · Nöbet ve ekip portalı';
$ogDesc = 'Nöbet listeleri, değişim ve devirler, eksik personel ilanları ve ekip mesajlaşması tek yerde. Giriş yaparak devam edin.';
$boot = json_encode(['v' => $v, 'csrf' => $_SESSION['csrf'], 'share' => (string)($_GET['s'] ?? ''), 'reset' => preg_replace('/[^a-f0-9]/', '', (string)($_GET['reset'] ?? '')), 'invite' => preg_replace('/[^A-Za-z0-9_-]/', '', (string)($_GET['davet'] ?? ''))], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
?><!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noimageindex">
  <meta name="theme-color" content="#1f8f80">
  <title><?= htmlspecialchars($org !== '' ? $org . ' · dupcii' : 'dupcii') ?></title>
  <meta name="description" content="<?= htmlspecialchars($ogDesc) ?>">
  <?= nm_og_tags($ogTitle, $ogDesc) ?>

  <link rel="manifest" href="manifest.php">
  <link rel="icon" href="<?= htmlspecialchars($favicon) ?>" type="<?= $favType ?>" id="favicon">
  <link rel="apple-touch-icon" href="<?= htmlspecialchars($touch) ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="assets/app.css?v=<?= $v ?>">
<?php foreach (['placement', 'requests', 'market', 'prefs', 'sohbet'] as $css): ?>
  <link rel="stylesheet" href="assets/css/<?= $css ?>.css?v=<?= $v ?>">
<?php endforeach; ?>
  <script id="nm-boot" type="application/json"><?= $boot ?></script>
  <script src="assets/theme.js?v=<?= $v ?>"></script>
</head>
<body>
  <div id="app"><div class="boot-splash"><div class="spinner"></div></div></div>
  <noscript>Bu uygulama için JavaScript gereklidir.</noscript>
<?php foreach (['core', 'auth', 'posts', 'viewer', 'rosters', 'admin', 'shiftparse', 'extras', 'taraf', 'placement', 'requests', 'market', 'ekstra', 'qrgiris', 'prefs', 'sistem', 'abonelik', 'basvuru', 'destek', 'guncelle', 'yasal', 'saglik', 'paylas', 'yetki', 'hastane', 'mesaj', 'mesaj2', 'mesaj3', 'mesaj4', 'arama', 'kisi', 'bildirim', 'plan', 'yemek', 'pwa', 'main'] as $js): ?>
  <script src="assets/js/<?= $js ?>.js?v=<?= $v ?>"></script>
<?php endforeach; ?>
</body>
</html>
