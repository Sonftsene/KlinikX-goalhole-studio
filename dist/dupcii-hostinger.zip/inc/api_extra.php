<?php
/**
 * dupcii — ek API işlemleri: bildirim merkezi, telefon bildirimi, rehber, nöbetlerim,
 * okuma raporu, yedekleme, işlem günlüğü, şablonlar, davetler, belge metni.
 * (api.php içindeki yardımcılar: s(), i(), b(), arr(), out(), fail(), need_user() …)
 */
declare(strict_types=1);

/* ---------------- Bildirim merkezi ---------------- */

function a_notif_list(): void
{
    $me = need_user();
    $rows = all('SELECT id, title, body, url, kind, created_at, read_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 40', [$me['id']]);
    out(['items' => array_map(fn($r) => ['id' => (int)$r['id'], 'title' => $r['title'], 'body' => $r['body'], 'url' => $r['url'], 'kind' => $r['kind'], 'at' => $r['created_at'], 'read' => $r['read_at'] !== null], $rows)]);
}

function a_notif_read(): void
{
    $me = need_user();
    $id = i('id');
    if ($id) q('UPDATE notifications SET read_at = ? WHERE id = ? AND user_id = ? AND read_at IS NULL', [now(), $id, $me['id']]);
    else q('UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL', [now(), $me['id']]);
    out();
}

/* ---------------- Telefon bildirimi (Web Push) ---------------- */

function a_push_key(): void
{
    need_user();
    if (!push_ready()) fail('Telefon bildirimleri bu sunucuda kullanılamıyor.', 400);
    $k = push_keys();
    if (!$k) fail('Bildirim anahtarı oluşturulamadı (OpenSSL gerekli).', 500);
    out(['key' => $k['public']]);
}

function a_push_subscribe(): void
{
    $me = need_user();
    $endpoint = s('endpoint', 2000);
    // Yalnızca bilinen push servisleri (FCM, Mozilla, Apple, Windows): sunucu başka adreslere istek atmasın.
    // Yerel geliştirme sunucusunda sahte push servisine izin verilir.
    $localDev = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true) && preg_match('#^http://127\.0\.0\.1:\d+/#', $endpoint);
    $allowed = function_exists('push_endpoint_allowed') ? push_endpoint_allowed($endpoint) : (bool)preg_match('#^https://#', $endpoint);
    if (!$allowed && !$localDev) fail('Geçersiz bildirim adresi.');
    $hash = hash('sha256', $endpoint);
    q('DELETE FROM push_subscriptions WHERE endpoint_hash = ?', [$hash]);
    q('INSERT INTO push_subscriptions (user_id, endpoint, endpoint_hash, p256dh, auth, created_at, label) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [$me['id'], $endpoint, $hash, s('p256dh', 255), s('auth', 100), now(), function_exists('nb_device_label') ? nb_device_label((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), b('app')) : null]);
    q('UPDATE users SET push_on = 1 WHERE id = ?', [$me['id']]);
    out();
}

function a_push_unsubscribe(): void
{
    $me = need_user();
    q('DELETE FROM push_subscriptions WHERE endpoint_hash = ? AND user_id = ?', [hash('sha256', s('endpoint', 2000)), $me['id']]);
    out();
}

function a_push_test(): void
{
    $me = need_user();
    notify_users([one('SELECT * FROM users WHERE id = ?', [$me['id']])], 'test', 'Bildirimler çalışıyor 🎉', 'Bu bir deneme bildirimidir.', '#/', null);
    out(['devices' => (int)val('SELECT COUNT(*) FROM push_subscriptions WHERE user_id = ?', [$me['id']])]);
}

/** Servis çalışanı (sw.js) push geldiğinde bunu çağırır: GET, oturum çerezine göre */
function a_push_pending_get(): void
{
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    // Yalnızca service worker'ın isteği (CSRF'siz GET olduğu için başka sitelerden tetiklenmesin)
    if (($_SERVER['HTTP_X_NM_SW'] ?? '') !== '1') { http_response_code(400); echo json_encode(['ok' => false]); return; }
    $me = current_user();
    if (!$me) { echo json_encode(['ok' => true, 'items' => []]); return; }
    if (function_exists('nb_payload') && empty($me['sa_virtual'])) {
        $p = nb_payload($me, date('Y-m-d H:i:s', time() - 900));
        echo json_encode(['ok' => true] + ($p ?? ['items' => []]), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return;
    }
    $rows = all('SELECT id, title, body, url FROM notifications WHERE user_id = ? AND read_at IS NULL AND created_at >= ? ORDER BY id DESC LIMIT 5', [$me['id'], date('Y-m-d H:i:s', time() - 900)]);
    $icon = brand_url('icon192'); // yöneticinin yüklediği uygulama simgesi (yoksa sw.js varsayılanı kullanır)
    echo json_encode(['ok' => true, 'items' => array_map(fn($r) => ['id' => (int)$r['id'], 'title' => $r['title'], 'body' => $r['body'], 'url' => $r['url'], 'tag' => 'n' . $r['id'], 'icon' => $icon], $rows)], JSON_UNESCAPED_UNICODE);
}

/* ---------------- Rehber ve bugün nöbette ---------------- */

function a_people_list(): void
{
    $me = need_user();
    $today = date('Y-m-d');
    $todayShifts = all("SELECT s.name, s.code, s.label, s.kind, s.start_time, s.end_time, r.name AS roster_name FROM roster_shifts s JOIN rosters r ON r.id = s.roster_id AND r.parsed_file_id = s.file_id WHERE s.date = ?", [$today]);
    $rows = all("SELECT id, name, email, phone, extension, title_id, unit_id, role, last_seen_at, avatar, ui_prefs FROM users WHERE status = 'active' ORDER BY name");
    out(['people' => array_map(function ($u) use ($todayShifts, $me) {
        $cv = contact_vis($u, $me);
        $on = null;
        foreach ($todayShifts as $s) if (names_match((string)$s['name'], (string)$u['name'])) { $on = ['code' => $s['code'], 'label' => $s['label'], 'kind' => $s['kind'], 'start' => $s['start_time'], 'end' => $s['end_time']]; break; }
        return ['id' => (int)$u['id'], 'name' => $u['name'], 'email' => $cv['email'] ? $u['email'] : null, 'phone' => $cv['phone'] ? $u['phone'] : null, 'extension' => $u['extension'],
            'title_id' => $u['title_id'] !== null ? (int)$u['title_id'] : null, 'unit_id' => $u['unit_id'] !== null ? (int)$u['unit_id'] : null,
            'role' => $u['role'], 'last_seen_at' => $u['last_seen_at'], 'avatar' => avatar_url($u), 'today' => $on];
    }, $rows)]);
}

/** Bugün (veya verilen gün) nöbette olanlar, vardiyaya göre gruplu */
function a_shifts_day(): void
{
    $me = need_user();
    $date = s('date', 10) ?: date('Y-m-d');
    if (!valid_ymd($date)) fail('Geçersiz tarih.');
    $rows = all("SELECT s.*, r.name AS roster_name FROM roster_shifts s JOIN rosters r ON r.id = s.roster_id AND r.parsed_file_id = s.file_id WHERE s.date = ? ORDER BY s.start_time, s.name", [$date]);
    // Dünden devam eden gece / 24 saat nöbetleri (bitiş saati başlangıçtan önce)
    $prev = date('Y-m-d', strtotime($date . ' -1 day'));
    $carry = all("SELECT s.*, r.name AS roster_name FROM roster_shifts s JOIN rosters r ON r.id = s.roster_id AND r.parsed_file_id = s.file_id WHERE s.date = ? AND s.kind = 'shift' AND s.start_time IS NOT NULL AND s.end_time IS NOT NULL AND s.end_time <= s.start_time ORDER BY s.name", [$prev]);
    $users = all("SELECT id, name, phone, extension, role, ui_prefs FROM users WHERE status = 'active'");
    foreach ($users as &$uu) { if (!contact_vis($uu, $me)['phone']) $uu['phone'] = null; } unset($uu);
    $find = function ($name) use ($users) { foreach ($users as $u) if (names_match((string)$name, (string)$u['name'])) return $u; return null; };
    $person = function ($r) use ($find) { $u = $find($r['name']); return ['name' => $r['name'], 'title' => $r['title'], 'user_id' => $u ? (int)$u['id'] : null, 'phone' => $u['phone'] ?? null, 'extension' => $u['extension'] ?? null, 'roster' => $r['roster_name']]; };
    $groups = [];
    foreach ($rows as $r) {
        $key = $r['kind'] . '|' . $r['code'];
        if (!isset($groups[$key])) $groups[$key] = ['code' => $r['code'], 'label' => $r['label'], 'kind' => $r['kind'], 'start' => $r['start_time'], 'end' => $r['end_time'], 'people' => []];
        $groups[$key]['people'][] = $person($r);
    }
    $out = array_values($groups);
    usort($out, fn($a, $b) => [$a['kind'] !== 'shift', $a['start'] ?? '99'] <=> [$b['kind'] !== 'shift', $b['start'] ?? '99']);
    out(['date' => $date, 'groups' => $out, 'carry' => array_map(fn($r) => $person($r) + ['code' => $r['code'], 'end' => $r['end_time']], $carry), 'has_data' => (bool)val('SELECT COUNT(*) FROM roster_shifts')]);
}

/** Benim nöbetlerim: önümüzdeki 60 gün + bu ay ve gelecek ay özeti için tüm ay */
function a_shifts_mine2(): void
{
    $me = need_user();
    $from = date('Y-m-d', strtotime('first day of last month'));
    $to = date('Y-m-d', strtotime('+70 days'));
    $rows = shifts_for_user($me, $from, $to);
    $moves = [];
    foreach (all('SELECT date, name, user_id, unit, to_side, from_side, counted, method FROM side_moves WHERE date >= ? AND date <= ?', [$from, $to]) as $m) {
        if ((int)($m['user_id'] ?? 0) === (int)$me['id'] || names_match((string)$m['name'], (string)$me['name'])) $moves[$m['date']] = ['unit' => $m['unit'], 'counted' => (bool)$m['counted'], 'method' => $m['method']];
    }
    out(['entries' => array_map('shift_row_out', $rows), 'moves' => (object)$moves, 'has_data' => (bool)val('SELECT COUNT(*) FROM roster_shifts'), 'name' => $me['name']]);
}

/** Tarayıcının Excel'den çıkardığı nöbetleri kaydeder (liste yükleyen yayıncı) */
function a_rosters_shifts_save(): void
{
    $me = need_publisher();
    $rid = (int)i('roster_id');
    $fid = (int)i('file_id');
    $period = s('period', 7);
    if (!valid_id('rosters', $rid)) fail('Liste bulunamadı.', 404);
    roster_not_linked($rid);
    if (!one('SELECT id FROM roster_files WHERE roster_id = ? AND attachment_id = ?', [$rid, $fid])) fail('Dosya bu listeye ait değil.', 400);
    if (!preg_match('/^\d{4}-\d{2}$/', $period)) fail('Geçersiz dönem.');
    $entries = array_slice(arr('entries'), 0, 6000);
    db()->beginTransaction();
    q('DELETE FROM roster_shifts WHERE roster_id = ?', [$rid]);
    $st = db()->prepare('INSERT INTO roster_shifts (roster_id, file_id, name, title, date, code, label, kind, hours, start_time, end_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $n = 0;
    foreach ($entries as $e) {
        if (!is_array($e)) continue;
        $name = mb_substr(trim((string)($e['name'] ?? '')), 0, 120);
        $date = (string)($e['date'] ?? '');
        $code = mb_substr(trim((string)($e['code'] ?? '')), 0, 20);
        if ($name === '' || $code === '' || !valid_ymd($date)) continue;
        $kind = in_array($e['kind'] ?? '', ['shift', 'leave', 'off', 'role'], true) ? $e['kind'] : 'shift';
        $hm = fn($v) => is_string($v) && preg_match('/^\d{2}:\d{2}$/', $v) ? $v : null;
        $st->execute([$rid, $fid, $name, mb_substr((string)($e['title'] ?? ''), 0, 80) ?: null, $date, $code, mb_substr((string)($e['label'] ?? ''), 0, 60) ?: null, $kind,
            isset($e['hours']) && is_numeric($e['hours']) ? (int)$e['hours'] : null, $hm($e['start'] ?? null), $hm($e['end'] ?? null)]);
        $n++;
    }
    q('UPDATE rosters SET period = ?, parsed_file_id = ? WHERE id = ?', [$period, $fid, $rid]);
    db()->commit();
    if (function_exists('swap_check_applied')) swap_check_applied($rid);
    audit($me, 'roster.parse', 'Liste #' . $rid, "$n nöbet kaydı, dönem $period");
    out(['saved' => $n]);
}

/** Listenin ayını düzelt: kayıtların tarihleri yeni aya taşınır */
function a_rosters_period(): void
{
    $me = need_publisher();
    $rid = (int)i('id');
    $period = s('period', 7);
    if (!preg_match('/^(\d{4})-(\d{2})$/', $period, $m) || (int)$m[2] < 1 || (int)$m[2] > 12) fail('Geçersiz dönem.');
    $r = one('SELECT * FROM rosters WHERE id = ?', [$rid]) ?? fail('Liste bulunamadı.', 404);
    roster_not_linked($rid);
    $days = (int)date('t', strtotime($period . '-01'));
    foreach (all('SELECT id, date FROM roster_shifts WHERE roster_id = ?', [$rid]) as $x) {
        $d = (int)substr($x['date'], 8, 2);
        if ($d > $days) q('DELETE FROM roster_shifts WHERE id = ?', [$x['id']]);
        else q('UPDATE roster_shifts SET date = ? WHERE id = ?', [$period . '-' . str_pad((string)$d, 2, '0', STR_PAD_LEFT), $x['id']]);
    }
    q('UPDATE rosters SET period = ? WHERE id = ?', [$period, $rid]);
    audit($me, 'roster.period', $r['name'], 'Dönem: ' . $period);
    out(['period' => $period]);
}

/* ---------------- Okuma raporu ---------------- */

function a_report_reads(): void
{
    need_publisher();
    $posts = all("SELECT p.id, p.title, p.unit_id, p.published_at, p.review_at, c.name AS category FROM posts p LEFT JOIN categories c ON c.id = p.category_id WHERE p.status = 'published' AND p.required = 1 ORDER BY p.published_at DESC LIMIT 200");
    $users = all("SELECT id, name, email, title_id, unit_id FROM users WHERE status = 'active' ORDER BY name");
    $acks = [];
    if ($posts) {
        $ids = implode(',', array_map(fn($p) => (int)$p['id'], $posts));
        foreach (all("SELECT post_id, user_id, created_at FROM acks WHERE post_id IN ($ids)") as $a) $acks[$a['post_id']][$a['user_id']] = $a['created_at'];
    }
    out(['posts' => array_map(fn($p) => ['id' => (int)$p['id'], 'title' => $p['title'], 'category' => $p['category'], 'unit_id' => $p['unit_id'] !== null ? (int)$p['unit_id'] : null, 'published_at' => $p['published_at'], 'review_at' => $p['review_at']], $posts),
        'users' => array_map(fn($u) => ['id' => (int)$u['id'], 'name' => $u['name'], 'email' => $u['email'], 'title_id' => $u['title_id'] !== null ? (int)$u['title_id'] : null, 'unit_id' => $u['unit_id'] !== null ? (int)$u['unit_id'] : null], $users),
        'acks' => (object)$acks, 'generated_at' => now()]);
}

/** Gözden geçirme tarihi yaklaşan / geçen belgeler */
function a_report_reviews(): void
{
    need_publisher();
    $rows = all("SELECT p.id, p.title, p.review_at, u.name AS author FROM posts p LEFT JOIN users u ON u.id = p.author_id WHERE p.status = 'published' AND p.review_at IS NOT NULL ORDER BY p.review_at LIMIT 200");
    out(['items' => array_map(fn($r) => ['id' => (int)$r['id'], 'title' => $r['title'], 'review_at' => $r['review_at'], 'author' => $r['author']], $rows)]);
}

/* ---------------- Yedekleme ---------------- */

function a_backup_list(): void
{
    need_admin();
    out(['items' => backup_list(), 'zip' => class_exists('ZipArchive'), 'weekly' => setting('backup_weekly', '1') === '1', 'last' => (int)setting('backup_last', '0') ? date('Y-m-d H:i:s', (int)setting('backup_last')) : null]);
}

function a_backup_create(): void
{
    $me = need_admin();
    try { $path = backup_create(false, true); } catch (Throwable $e) { fail($e->getMessage()); }
    set_setting('backup_last', (string)time());
    audit($me, 'backup.create', basename($path));
    out(['items' => backup_list()]);
}

function a_backup_delete(): void
{
    $me = need_admin();
    $name = basename(s('name', 120));
    if (!preg_match('/^(dupcii|nobetmed)-yedek-[\w-]+\.zip$/', $name)) fail('Geçersiz dosya.');
    @unlink(backup_dir() . '/' . $name);
    audit($me, 'backup.delete', $name);
    out(['items' => backup_list()]);
}

/** GET: yedeği indir. ?name=… (kayıtlı yedek) veya ?full=0|1 (anlık yedek). CSRF anahtarı sorguda. */
function a_backup_download_get(): void
{
    nm_session();
    $me = current_user();
    if (!$me || $me['role'] !== 'admin' || !hash_equals((string)$_SESSION['csrf'], (string)($_GET['csrf'] ?? ''))) {
        http_response_code(403);
        echo 'Yetkiniz yok veya oturum süresi doldu.';
        return;
    }
    if (function_exists('set_time_limit')) @set_time_limit(0);
    $name = basename((string)($_GET['name'] ?? ''));
    $temp = false;
    if ($name !== '' && preg_match('/^(dupcii|nobetmed)-yedek-[\w-]+\.zip$/', $name)) {
        $path = backup_dir() . '/' . $name;
    } else {
        try {
            $path = backup_create(!empty($_GET['full']), false);
            $temp = true;
        } catch (Throwable $e) {
            // ZIP yoksa yalnızca veritabanını gönder
            $tmp = backup_dir() . '/tmp-' . bin2hex(random_bytes(4));
            mkdir($tmp);
            $path = backup_database_file($tmp);
            $temp = true;
        }
    }
    if (!is_file($path)) { http_response_code(404); echo 'Yedek bulunamadı.'; return; }
    audit($me, 'backup.download', basename($path));
    session_write_close();
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($path) . '"');
    header('Content-Length: ' . filesize($path));
    header('Cache-Control: no-store');
    while (ob_get_level()) ob_end_clean();
    readfile($path);
    if ($temp) { @unlink($path); @rmdir(dirname($path)); }
}

/* ---------------- İşlem günlüğü ---------------- */

function a_audit_list(): void
{
    need_admin();
    $q = s('q', 80);
    $offset = max(0, (int)i('offset'));
    $p = [];
    $where = '1=1';
    if ($q !== '') {
        $p[':q1'] = like_pattern($q); $p[':q2'] = $p[':q1']; $p[':q3'] = $p[':q1']; $p[':q4'] = $p[':q1'];
        $where = '(' . like_expr('user_name') . ' LIKE :q1 OR ' . like_expr('action') . ' LIKE :q2 OR ' . like_expr('target') . ' LIKE :q3 OR ' . like_expr('detail') . ' LIKE :q4)';
    }
    $rows = all("SELECT * FROM audit_log WHERE $where ORDER BY id DESC LIMIT 51 OFFSET $offset", $p);
    out(['items' => array_map(fn($r) => ['id' => (int)$r['id'], 'user' => $r['user_name'], 'action' => $r['action'], 'target' => $r['target'], 'detail' => $r['detail'], 'ip' => $r['ip'], 'at' => $r['at']], array_slice($rows, 0, 50)), 'has_more' => count($rows) > 50]);
}

/* ---------------- Duyuru şablonları ---------------- */

function a_templates_list(): void
{
    need_user();
    out(['items' => array_map(fn($t) => ['id' => (int)$t['id'], 'title' => $t['title'], 'body' => $t['body'], 'category_id' => $t['category_id'] !== null ? (int)$t['category_id'] : null, 'required' => (bool)$t['required']], all('SELECT * FROM templates ORDER BY sort, id'))]);
}

function a_templates_save(): void
{
    $me = need_publisher();
    $title = s('title', 200);
    $body = s('body', 20000);
    if (mb_strlen($title) < 2 || $body === '') fail('Şablon adı ve metni gerekli.');
    $cat = i('category_id');
    if ($cat !== null && !valid_id('categories', $cat)) $cat = null;
    q('INSERT INTO templates (title, body, category_id, required, created_by, created_at, sort) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [$title, $body, $cat, b('required') ? 1 : 0, $me['id'], now(), (int)val('SELECT COALESCE(MAX(sort), 0) + 1 FROM templates')]);
    audit($me, 'template.create', $title);
    a_templates_list();
}

function a_templates_delete(): void
{
    $me = need_publisher();
    $t = one('SELECT title FROM templates WHERE id = ?', [(int)i('id')]);
    q('DELETE FROM templates WHERE id = ?', [(int)i('id')]);
    if ($t) audit($me, 'template.delete', $t['title']);
    a_templates_list();
}

/* ---------------- Davetler (QR ile kayıt, listeden toplu hesap) ---------------- */

function invite_out(array $r): array
{
    return ['id' => (int)$r['id'], 'token' => $r['token'], 'kind' => $r['kind'], 'name' => $r['name'], 'email' => $r['email'],
        'title_id' => $r['title_id'] !== null ? (int)$r['title_id'] : null, 'unit_id' => $r['unit_id'] !== null ? (int)$r['unit_id'] : null,
        'role' => $r['role'], 'auto_approve' => (bool)$r['auto_approve'], 'uses' => (int)$r['uses'], 'max_uses' => (int)$r['max_uses'],
        'expires' => $r['expires'], 'created_at' => $r['created_at'], 'used' => $r['used_by'] !== null || ((int)$r['uses'] >= (int)$r['max_uses']),
        'url' => base_url() . '?davet=' . $r['token'] . nm_link_param()];
}

function a_invites_list(): void
{
    need_admin();
    out(['items' => array_map('invite_out', all('SELECT * FROM invites WHERE revoked = 0 AND (expires IS NULL OR expires > ?) ORDER BY id DESC LIMIT 300', [now()]))]);
}

function a_invites_general(): void
{
    $me = need_admin();
    $unit = i('unit_id');
    if ($unit !== null && !valid_id('units', $unit)) $unit = null;
    $days = max(1, min(365, (int)(i('days') ?? 30)));
    $token = random_token(12);
    q('INSERT INTO invites (token, kind, unit_id, role, auto_approve, max_uses, uses, expires, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?)',
        [$token, 'general', $unit, 'member', b('auto_approve') ? 1 : 0, 500, date('Y-m-d H:i:s', time() + $days * 86400), $me['id'], now()]);
    audit($me, 'invite.general', 'QR davet', ($unit ? unit_name_of($unit) : 'Tüm birimler') . ", $days gün");
    out(['invite' => invite_out(one('SELECT * FROM invites WHERE token = ?', [$token]))]);
}

function unit_name_of(?int $id): string
{
    return $id ? (string)(val('SELECT name FROM units WHERE id = ?', [$id]) ?: '') : '';
}

/** Nöbet listelerindeki adlardan, henüz hesabı olmayanlar */
function a_invites_candidates(): void
{
    need_admin();
    $names = all('SELECT s.name, MAX(s.title) AS title FROM roster_shifts s JOIN rosters r ON r.id = s.roster_id AND r.parsed_file_id = s.file_id GROUP BY s.name ORDER BY s.name');
    $users = all('SELECT name FROM users');
    $invited = all("SELECT name FROM invites WHERE kind = 'personal' AND revoked = 0 AND used_by IS NULL AND name IS NOT NULL");
    $titles = all('SELECT id, name FROM titles');
    $out = [];
    foreach ($names as $n) {
        $nm = (string)$n['name'];
        foreach ($users as $u) if (names_match($nm, (string)$u['name'])) continue 2;
        $inv = false;
        foreach ($invited as $iv) if (names_match($nm, (string)$iv['name'])) { $inv = true; break; }
        $tid = null;
        foreach ($titles as $t) if (tr_lower((string)$t['name']) === tr_lower(trim((string)$n['title']))) $tid = (int)$t['id'];
        $out[] = ['name' => mb_convert_case(mb_strtolower(str_replace(['İ', 'I'], ['i', 'ı'], $nm), 'UTF-8'), MB_CASE_TITLE, 'UTF-8'), 'roster_name' => $nm, 'title' => $n['title'], 'title_id' => $tid, 'invited' => $inv];
    }
    out(['items' => $out]);
}

function a_invites_personal(): void
{
    $me = need_admin();
    $created = [];
    $mailed = 0;
    foreach (array_slice(arr('people'), 0, 200) as $p) {
        if (!is_array($p)) continue;
        $name = mb_substr(trim((string)($p['name'] ?? '')), 0, 120);
        if (mb_strlen($name) < 3) continue;
        $email = mb_substr(mb_strtolower(trim((string)($p['email'] ?? ''))), 0, 190);
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $email = '';
        if ($email !== '' && one('SELECT id FROM users WHERE email = ?', [$email])) continue;
        $tid = isset($p['title_id']) && valid_id('titles', (int)$p['title_id']) ? (int)$p['title_id'] : null;
        $uid = isset($p['unit_id']) && valid_id('units', (int)$p['unit_id']) ? (int)$p['unit_id'] : null;
        $token = random_token(12);
        q('INSERT INTO invites (token, kind, name, email, title_id, unit_id, role, auto_approve, max_uses, uses, expires, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 1, 1, 0, ?, ?, ?)',
            [$token, 'personal', $name, $email ?: null, $tid, $uid, 'member', date('Y-m-d H:i:s', time() + 60 * 86400), $me['id'], now()]);
        $inv = invite_out(one('SELECT * FROM invites WHERE token = ?', [$token]));
        $created[] = $inv;
        if ($email !== '' && mail_ready()) {
            $mailed += mail_queue_to([['name' => $name, 'email' => $email]], 'Portala davetlisiniz', 'Merhaba ' . explode(' ', $name)[0] . ', portala davetlisiniz',
                [setting('org_name', 'Klinik Portalı') . ' ekibine katılmanız için hesabınız hazırlandı. Aşağıdaki bağlantıdan e-postanızı ve şifrenizi belirleyerek hemen giriş yapabilirsiniz.', 'Bağlantı size özeldir ve 60 gün geçerlidir.'],
                'Hesabımı oluştur', $inv['url'], 'invite', false);
        }
    }
    audit($me, 'invite.personal', count($created) . ' kişisel davet', $mailed ? "$mailed e-posta" : '');
    out(['items' => $created, 'mailed' => $mailed]);
}

function a_invites_revoke(): void
{
    $me = need_admin();
    q('UPDATE invites SET revoked = 1 WHERE id = ?', [(int)i('id')]);
    audit($me, 'invite.revoke', 'Davet #' . (int)i('id'));
    out();
}

/** Herkese açık: davet bilgisini göster (kayıt formu için) */
function invite_valid(string $token): ?array
{
    if ($token === '') return null;
    $r = one('SELECT * FROM invites WHERE token = ? AND revoked = 0', [$token]);
    if (!$r || ($r['expires'] && $r['expires'] < now()) || (int)$r['uses'] >= (int)$r['max_uses']) return null;
    return $r;
}

function a_invite_get(): void
{
    $r = invite_valid(s('token', 40));
    if (!$r) fail('Bu davet bağlantısı geçersiz, kullanılmış veya süresi dolmuş. Yöneticinizden yeni bağlantı isteyin.', 404);
    out(['invite' => ['kind' => $r['kind'], 'name' => $r['name'], 'email' => $r['email'], 'title_id' => $r['title_id'] !== null ? (int)$r['title_id'] : null, 'unit_id' => $r['unit_id'] !== null ? (int)$r['unit_id'] : null, 'auto_approve' => (bool)$r['auto_approve']], 'org_name' => setting('org_name', 'Klinik Portalı')]);
}

/* ---------------- Belge metni (belge içinde arama) ---------------- */

function a_attachments_text(): void
{
    $me = need_user();
    $id = (int)i('id');
    $a = one('SELECT * FROM attachments WHERE id = ?', [$id]) ?? fail('Dosya bulunamadı.', 404);
    if ((int)$a['user_id'] !== (int)$me['id'] && !is_publisher($me)) fail('Yetkiniz yok.', 403);
    // Başkasının dosyasında yalnız henüz çıkarılmamış metin doldurulur (var olan arama metni üzerine yazılamaz)
    if ((int)$a['user_id'] !== (int)$me['id'] && (int)($a['text_done'] ?? 0) === 1) out(['length' => mb_strlen((string)($a['text_content'] ?? ''))]);
    global $IN;
    $text = is_string($IN['text'] ?? null) ? $IN['text'] : '';
    $text = mb_substr(preg_replace('/[ \t]+/u', ' ', str_replace("\0", '', $text)), 0, 400000);
    q('UPDATE attachments SET text_content = ?, text_done = 1 WHERE id = ?', [$text, $id]);
    out(['length' => mb_strlen($text)]);
}

/* ---------------- Parmak izi / Face ID ile giriş (passkey) ---------------- */

function passkey_ready(): void
{
    if (!function_exists('wa_verify_registration')) fail('Bu sunucuda parmak izi ile giriş kullanılamıyor.', 400);
}

function a_passkey_reg_begin(): void
{
    $me = need_user();
    passkey_ready();
    $challenge = random_bytes(32);
    $_SESSION['wa_reg'] = ['v' => $challenge, 't' => time()];
    $exclude = array_map(fn($r) => ['type' => 'public-key', 'id' => $r['credential_id']], all('SELECT credential_id FROM passkeys WHERE user_id = ?', [$me['id']]));
    out(['publicKey' => [
        'challenge' => wa_b64u_enc($challenge),
        'rp' => ['name' => setting('org_name', 'dupcii'), 'id' => wa_rp_id_from_server()],
        'user' => ['id' => wa_b64u_enc(nm_passkey_handle((int)$me['id'])), 'name' => $me['email'], 'displayName' => $me['name']],
        'pubKeyCredParams' => [['type' => 'public-key', 'alg' => -7], ['type' => 'public-key', 'alg' => -257]],
        'authenticatorSelection' => ['residentKey' => 'required', 'requireResidentKey' => true, 'userVerification' => 'required'],
        'attestation' => 'none',
        'timeout' => 60000,
        'excludeCredentials' => $exclude,
    ]]);
}

function passkey_take_challenge(string $kind): string
{
    $c = $_SESSION['wa_' . $kind] ?? null;
    unset($_SESSION['wa_' . $kind]);
    if (!$c || $c['t'] < time() - 300) return '';
    return $c['v'];
}

function device_label(): string
{
    $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
    $os = preg_match('/iPhone/i', $ua) ? 'iPhone' : (preg_match('/iPad/i', $ua) ? 'iPad' : (preg_match('/Android/i', $ua) ? 'Android' : (preg_match('/Mac OS X/i', $ua) ? 'Mac' : (preg_match('/Windows/i', $ua) ? 'Windows' : 'Cihaz'))));
    $br = preg_match('/Edg\//', $ua) ? 'Edge' : (preg_match('/Chrome\//', $ua) ? 'Chrome' : (preg_match('/Safari\//', $ua) ? 'Safari' : (preg_match('/Firefox\//', $ua) ? 'Firefox' : '')));
    return trim("$os $br");
}

function a_passkey_reg_finish(): void
{
    $me = need_user();
    passkey_ready();
    try {
        $r = wa_verify_registration(wa_b64u_dec(s('clientDataJSON', 20000)), wa_b64u_dec(s('attestationObject', 20000)), passkey_take_challenge('reg'), wa_origin_from_server(), wa_rp_id_from_server());
    } catch (Throwable $e) { fail($e->getMessage()); }
    $cid = wa_b64u_enc($r['credential_id']);
    if (one('SELECT id FROM passkeys WHERE credential_id = ?', [$cid])) fail('Bu cihaz zaten kayıtlı.', 409);
    q('INSERT INTO passkeys (user_id, credential_id, public_key, sign_count, name, created_at) VALUES (?, ?, ?, ?, ?, ?)',
        [$me['id'], $cid, $r['public_key_pem'], (int)$r['sign_count'], device_label(), now()]);
    audit($me, 'passkey.add', device_label());
    a_passkey_list();
}

function a_passkey_list(): void
{
    $me = need_user();
    out(['items' => array_map(fn($r) => ['id' => (int)$r['id'], 'name' => $r['name'], 'created_at' => $r['created_at'], 'last_used_at' => $r['last_used_at']], all('SELECT * FROM passkeys WHERE user_id = ? ORDER BY id', [$me['id']]))]);
}

function a_passkey_delete(): void
{
    $me = need_user();
    q('DELETE FROM passkeys WHERE id = ? AND user_id = ?', [(int)i('id'), $me['id']]);
    audit($me, 'passkey.delete', 'Kayıt #' . (int)i('id'));
    a_passkey_list();
}

function a_passkey_login_begin(): void
{
    passkey_ready();
    $challenge = random_bytes(32);
    $_SESSION['wa_login'] = ['v' => $challenge, 't' => time()];
    out(['publicKey' => ['challenge' => wa_b64u_enc($challenge), 'rpId' => wa_rp_id_from_server(), 'allowCredentials' => [], 'userVerification' => 'required', 'timeout' => 60000]]);
}

function a_passkey_login_finish(): void
{
    passkey_ready();
    $cid = s('rawId', 1000);
    $pk = $cid !== '' ? one('SELECT * FROM passkeys WHERE credential_id = ?', [wa_b64u_enc(wa_b64u_dec($cid))]) : null;
    if (!$pk) fail('Bu cihaz için kayıtlı bir giriş bulunamadı. Önce şifreyle girip Hesabım sayfasından parmak izini ekleyin.', 404);
    $uh = s('userHandle', 200);
    if ($uh !== '' && !in_array(wa_b64u_dec($uh), ['u' . $pk['user_id'], nm_passkey_handle((int)$pk['user_id'])], true)) fail('Doğrulama başarısız.', 401);
    try {
        $count = wa_verify_assertion(wa_b64u_dec(s('clientDataJSON', 20000)), wa_b64u_dec(s('authenticatorData', 5000)), wa_b64u_dec(s('signature', 2000)), passkey_take_challenge('login'), wa_origin_from_server(), wa_rp_id_from_server(), $pk['public_key'], (int)$pk['sign_count']);
    } catch (Throwable $e) { fail($e->getMessage(), 401); }
    $u = one('SELECT * FROM users WHERE id = ?', [$pk['user_id']]);
    if (!$u || $u['status'] !== 'active') fail('Hesabınız etkin değil.', 403);
    q('UPDATE passkeys SET sign_count = ?, last_used_at = ? WHERE id = ?', [$count, now(), $pk['id']]);
    login_user($u);
    audit($u, 'login.passkey', $pk['name'] ?? '');
    out(['must_change' => (int)($u['must_change'] ?? 0) === 1]);
}


/* ---------------- Nöbet kodu sözlüğü (yönetici düzenler) ---------------- */

/** Kayıtlı sözlük; yoksa null (tarayıcı varsayılan sözlüğü kullanır) */
function shift_codes(): ?array
{
    $j = json_decode((string)setting('shift_codes', ''), true);
    return is_array($j) && $j ? $j : null;
}

function a_shiftcodes_save(): void
{
    $me = need_admin();
    global $IN;
    if (!empty($IN['reset'])) {
        set_setting('shift_codes', '');
        audit($me, 'settings.save', 'Nöbet kodları', 'Varsayılana döndü');
        out(['codes' => null]);
    }
    $hm = fn($v) => is_string($v) && preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $v) ? $v : null;
    $codes = [];
    $seen = [];
    foreach (array_slice(is_array($IN['codes'] ?? null) ? $IN['codes'] : [], 0, 80) as $c) {
        if (!is_array($c)) continue;
        $code = mb_substr(trim((string)($c['code'] ?? '')), 0, 12);
        if ($code === '' || isset($seen[mb_strtolower($code)])) continue;
        $seen[mb_strtolower($code)] = 1;
        $kind = in_array($c['kind'] ?? '', ['shift', 'leave', 'off'], true) ? $c['kind'] : 'shift';
        $start = $kind === 'shift' ? $hm($c['start'] ?? null) : null;
        $end = $kind === 'shift' ? $hm($c['end'] ?? null) : null;
        $hours = 0;
        if ($start && $end) {
            $m = ((int)substr($end, 0, 2) * 60 + (int)substr($end, 3)) - ((int)substr($start, 0, 2) * 60 + (int)substr($start, 3));
            if ($m <= 0) $m += 1440;
            $hours = round($m / 60, 1);
        } elseif ($kind === 'shift' && is_numeric($c['hours'] ?? null)) {
            $hours = max(0, min(48, (float)$c['hours']));
        }
        $aliases = array_values(array_filter(array_map(fn($a) => mb_substr(trim((string)$a), 0, 30), array_slice(is_array($c['aliases'] ?? null) ? $c['aliases'] : [], 0, 10)), fn($a) => $a !== ''));
        $row = ['code' => $code, 'label' => mb_substr(trim((string)($c['label'] ?? '')), 0, 40) ?: $code, 'start' => $start, 'end' => $end, 'hours' => $hours, 'kind' => $kind];
        if ($start && $end && $end <= $start) $row['nextDay'] = true;
        if ($aliases) $row['aliases'] = $aliases;
        $codes[] = $row;
    }
    if (!$codes) fail('En az bir kod girin.');
    set_setting('shift_codes', json_encode($codes, JSON_UNESCAPED_UNICODE));
    audit($me, 'settings.save', 'Nöbet kodları', count($codes) . ' kod');
    out(['codes' => $codes]);
}

/* ---------------- Yönetici kurulum listesi ---------------- */

function a_setup_status(): void
{
    need_admin();
    $cron = (int)setting('cron_last', '0');
    $rosterPeople = [];
    foreach (all('SELECT DISTINCT s.name FROM roster_shifts s JOIN rosters r ON r.id = s.roster_id AND r.parsed_file_id = s.file_id') as $x) $rosterPeople[] = (string)$x['name'];
    $users = all("SELECT name FROM users WHERE status = 'active'");
    $matched = 0;
    foreach ($rosterPeople as $n) foreach ($users as $u) if (names_match($n, (string)$u['name'])) { $matched++; break; }
    out(['status' => [
        'mail' => mail_ready(),
        'cron' => $cron > time() - 2 * 86400,
        'cron_last' => $cron ? date('Y-m-d H:i:s', $cron) : null,
        'roster' => (bool)val('SELECT COUNT(*) FROM roster_files'),
        'parsed' => (bool)val('SELECT COUNT(*) FROM roster_shifts'),
        'roster_people' => count($rosterPeople),
        'matched' => $matched,
        'users' => count($users),
        'push' => push_ready(),
    ]]);
}


/* ---------------- Profil fotoğrafı ve e-posta ---------------- */

function avatar_url(array $u): ?string
{
    $a = (string)($u['avatar'] ?? '');
    return $a !== '' ? 'api.php?action=avatar&u=' . (int)$u['id'] . '&v=' . substr($a, 0, 10) : null;
}

function avatar_dir(): string
{
    $d = nm_upload_dir() . '/avatars';
    if (!is_dir($d)) @mkdir($d, 0775, true);
    return $d;
}

function avatar_delete_file(array $u): void
{
    $a = basename((string)($u['avatar'] ?? ''));
    if ($a !== '' && is_file(avatar_dir() . '/' . $a)) @unlink(avatar_dir() . '/' . $a);
}

/** Profil fotoğrafı yükle / kaldır. Tarayıcı fotoğrafı kare olarak kırpıp küçültür (en fazla 512 px). */
function a_me_avatar(): void
{
    $me = need_user();
    global $IN;
    $target = $me;
    // Yönetici, uygunsuz bir fotoğrafı başkası için kaldırabilir
    if (!empty($IN['user_id']) && (int)$IN['user_id'] !== (int)$me['id']) {
        if ($me['role'] !== 'admin' || empty($IN['remove'])) fail('Yetkiniz yok.', 403);
        $target = one('SELECT * FROM users WHERE id = ?', [(int)$IN['user_id']]) ?? fail('Kullanıcı bulunamadı.', 404);
    }
    if (!empty($IN['remove'])) {
        avatar_delete_file($target);
        q('UPDATE users SET avatar = NULL WHERE id = ?', [$target['id']]);
        if ((int)$target['id'] !== (int)$me['id']) audit($me, 'user.edit', $target['name'], 'Profil fotoğrafı kaldırıldı');
        out(['avatar' => null]);
    }
    $data = (string)($IN['data'] ?? '');
    if (!preg_match('#^data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$#', $data, $m)) fail('Geçersiz fotoğraf.');
    $bin = base64_decode($m[2], true);
    if ($bin === false || strlen($bin) > 600000) fail('Fotoğraf çok büyük.');
    $info = @getimagesizefromstring($bin);
    $types = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
    if (!$info || !isset($types[$info[2]]) || $info[0] < 16 || $info[1] < 16 || $info[0] > 1024 || $info[1] > 1024) fail('Fotoğraf okunamadı. JPG veya PNG deneyin.');
    $name = bin2hex(random_bytes(8)) . '.' . $types[$info[2]];
    if (@file_put_contents(avatar_dir() . '/' . $name, $bin) === false) fail('Fotoğraf kaydedilemedi (klasör yazma izni).', 500);
    avatar_delete_file($me);
    q('UPDATE users SET avatar = ? WHERE id = ?', [$name, $me['id']]);
    out(['avatar' => avatar_url(['id' => $me['id'], 'avatar' => $name])]);
}

/** Profil fotoğrafını göster: yalnızca giriş yapmış kişiler görür */
function a_avatar_get(): void
{
    nm_session();
    if (!current_user()) { http_response_code(404); exit; }
    $u = one('SELECT id, avatar FROM users WHERE id = ?', [(int)($_GET['u'] ?? 0)]);
    $a = $u ? basename((string)$u['avatar']) : '';
    $path = $a !== '' ? avatar_dir() . '/' . $a : '';
    if ($path === '' || !is_file($path)) { http_response_code(404); exit; }
    session_write_close();
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    header('Content-Type: ' . (['jpg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'][$ext] ?? 'application/octet-stream'));
    header('Content-Length: ' . filesize($path));
    header('Cache-Control: private, max-age=31536000, immutable');
    header('X-Content-Type-Options: nosniff');
    header("Content-Security-Policy: default-src 'none'");
    readfile($path);
}

/** E-posta adresini değiştir (giriş adresi). Şifreyle doğrulanır. */
function a_me_email(): void
{
    $me = need_user();
    global $IN;
    $email = mb_strtolower(trim(s('email', 190)));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Geçerli bir e-posta adresi girin.');
    if (empty($me['password_hash'])) fail('Önce Güvenlik bölümünden bir şifre belirleyin.');
    if (!password_verify((string)($IN['current'] ?? ''), $me['password_hash'])) fail('Şifre hatalı.');
    if ($email === mb_strtolower((string)$me['email'])) out(['email' => $email]);
    if (one('SELECT id FROM users WHERE LOWER(email) = ? AND id <> ?', [$email, $me['id']])) fail('Bu e-posta başka bir hesapta kullanılıyor.', 409);
    nm_email_guard($email);
    q('UPDATE users SET email = ? WHERE id = ?', [$email, $me['id']]);
    nm_dir_del((string)$me['email']);
    nm_dir_put($email);
    audit($me, 'user.edit', $me['name'], 'E-posta değişti: ' . $me['email'] . ' → ' . $email);
    out(['email' => $email]);
}


/* ---------------- Marka: özel logo, favicon ve logo boyutu ---------------- */

const BRAND_KINDS = ['logo', 'logo_dark', 'icon', 'icon192', 'icon512'];

function brand_dir(): string
{
    $d = nm_upload_dir() . '/brand';
    if (!is_dir($d)) @mkdir($d, 0775, true);
    return $d;
}

function brand_url(string $kind): ?string
{
    $f = (string)setting('brand_' . $kind, '');
    return $f !== '' ? 'api.php?action=brand&f=' . $kind . '&v=' . substr(md5($f), 0, 10) . nm_link_param() : null;
}

/** Herkese açık marka bilgisi (giriş ekranında da gerekir) */
function brand_out(): array
{
    return [
        'logo' => brand_url('logo'),
        'logo_dark' => brand_url('logo_dark'),
        'icon' => brand_url('icon'),
        'icon192' => brand_url('icon192'),
        'logo_h' => max(20, min(96, (int)setting('brand_logo_h', '36'))),
    ];
}

/** Yönetici: logo/favicon yükle, kaldır veya logo boyutunu değiştir */
function a_brand_save(): void
{
    $me = need_admin();
    global $IN;
    if (array_key_exists('logo_h', $IN)) set_setting('brand_logo_h', (string)max(20, min(96, (int)$IN['logo_h'])));
    foreach (BRAND_KINDS as $kind) {
        if (!array_key_exists($kind, $IN)) continue;
        $old = (string)setting('brand_' . $kind, '');
        $data = $IN[$kind];
        if ($data === null || $data === '' || $data === false) {
            if ($old !== '') @unlink(brand_dir() . '/' . basename($old));
            set_setting('brand_' . $kind, '');
            continue;
        }
        if (!is_string($data) || !preg_match('#^data:image/(png|jpeg|webp|svg\+xml|x-icon|vnd\.microsoft\.icon);base64,([A-Za-z0-9+/=]+)$#', $data, $m)) fail('Geçersiz görsel. PNG, JPG, WebP, SVG veya ICO yükleyin.');
        $bin = base64_decode($m[2], true);
        if ($bin === false || strlen($bin) > 2 * 1048576) fail('Görsel en fazla 2 MB olabilir.');
        $ext = ['png' => 'png', 'jpeg' => 'jpg', 'webp' => 'webp', 'svg+xml' => 'svg', 'x-icon' => 'ico', 'vnd.microsoft.icon' => 'ico'][$m[1]];
        if ($ext === 'svg') {
            // SVG: yalnızca görsel olarak gösterilir; betik/olay içeren dosya kabul edilmez
            if (!preg_match('/<svg[\s>]/i', $bin) || preg_match('/<script|\son[a-z]+\s*=|javascript:|<foreignObject/i', $bin)) fail('Bu SVG dosyası kullanılamıyor (betik içeriyor).');
        } elseif ($ext !== 'ico') {
            $info = @getimagesizefromstring($bin);
            if (!$info || $info[0] < 8 || $info[1] < 8 || $info[0] > 4096 || $info[1] > 4096) fail('Görsel okunamadı.');
        }
        $name = $kind . '-' . bin2hex(random_bytes(6)) . '.' . $ext;
        if (@file_put_contents(brand_dir() . '/' . $name, $bin) === false) fail('Görsel kaydedilemedi (klasör yazma izni).', 500);
        if ($old !== '') @unlink(brand_dir() . '/' . basename($old));
        set_setting('brand_' . $kind, $name);
    }
    audit($me, 'settings.save', 'Logo ve simge');
    out(['brand' => brand_out()]);
}

/** Logo/simge dosyasını göster (giriş ekranında da göründüğü için herkese açık) */
function a_brand_get(): void
{
    $kind = (string)($_GET['f'] ?? '');
    if (!in_array($kind, BRAND_KINDS, true)) { http_response_code(404); exit; }
    $f = basename((string)setting('brand_' . $kind, ''));
    $path = $f !== '' ? brand_dir() . '/' . $f : '';
    if ($path === '' || !is_file($path)) { http_response_code(404); exit; }
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    header('Content-Type: ' . (['png' => 'image/png', 'jpg' => 'image/jpeg', 'webp' => 'image/webp', 'svg' => 'image/svg+xml', 'ico' => 'image/x-icon'][$ext] ?? 'application/octet-stream'));
    header('Content-Length: ' . filesize($path));
    header('Cache-Control: public, max-age=31536000, immutable');
    header('X-Content-Type-Options: nosniff');
    header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; sandbox");
    readfile($path);
}


/* ---------------- Dahili telefon rehberi ---------------- */

/** Numara alanını temizler: rakam, boşluk ve + ( ) - / . , dışında karakter kabul etmez. Geçersizse ''. */
function pb_number(string $v): string
{
    $v = trim(preg_replace('/\s+/u', ' ', $v));
    if ($v === '' || mb_strlen($v) > 40 || !preg_match('/\d/', $v) || !preg_match('/^[0-9+()\/\-., ]+$/', $v)) return '';
    return $v;
}

function pb_out(array $r): array
{
    return ['id' => (int)$r['id'], 'name' => $r['name'], 'number' => $r['number'], 'category' => (string)$r['category'],
        'note' => (string)$r['note'], 'pinned' => (bool)$r['pinned'], 'scope' => 'birim', 'own' => true];
}

function a_phonebook_list(): void
{
    need_user();
    out(phonebook_payload());
}

/** Birim numaraları + hastane ortak rehberi (hastane numaraları negatif kimlikli) */
function phonebook_payload(): array
{
    $hosp = function_exists('hpb_items') ? hpb_items() : [];
    return ['items' => array_merge(array_map('pb_out', all('SELECT * FROM phonebook ORDER BY sort, id')), $hosp), 'santral' => setting('pb_santral', ''), 'dial' => setting('pb_dial', 'auto'),
        'hospital' => function_exists('hdb') && hdb() ? (string)(nm_tenant()['hospital_name'] ?? '') : null];
}

function a_phonebook_save(): void
{
    $me = need_publisher();
    $id = i('id');
    $name = s('name', 120);
    $num = pb_number(s('number', 60));
    if (mb_strlen($name) < 2) fail('Ad en az 2 karakter olmalı.');
    if ($num === '') fail('Numara yalnızca rakam ve + ( ) - / işaretleri içerebilir.');
    $row = [$name, $num, s('category', 60), s('note', 200), b('pinned') ? 1 : 0, $me['id'], now()];
    if (function_exists('hpb_save') && hpb_save($me, $id, [$name, $num, s('category', 60), s('note', 200), b('pinned') ? 1 : 0])) { a_phonebook_list(); return; }
    if ($id) {
        if (!one('SELECT id FROM phonebook WHERE id = ?', [$id])) fail('Kayıt bulunamadı.', 404);
        q('UPDATE phonebook SET name = ?, number = ?, category = ?, note = ?, pinned = ?, updated_by = ?, updated_at = ? WHERE id = ?', [...$row, $id]);
        audit($me, 'phonebook.save', $name, $num);
    } else {
        q('INSERT INTO phonebook (name, number, category, note, pinned, updated_by, updated_at, sort) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [...$row, (int)val('SELECT COALESCE(MAX(sort), 0) + 1 FROM phonebook')]);
        audit($me, 'phonebook.create', $name, $num);
    }
    a_phonebook_list();
}

function a_phonebook_delete(): void
{
    $me = need_publisher();
    if ((int)i('id') < 0 && function_exists('hpb_delete')) { hpb_delete($me, (int)i('id')); a_phonebook_list(); return; }
    $r = one('SELECT name, number FROM phonebook WHERE id = ?', [(int)i('id')]);
    if (!$r) fail('Kayıt bulunamadı.', 404);
    q('DELETE FROM phonebook WHERE id = ?', [(int)i('id')]);
    audit($me, 'phonebook.delete', $r['name'], $r['number']);
    a_phonebook_list();
}

/** Toplu ekleme: istemci yapıştırılan metni satırlara ayırır; burada her satır yeniden doğrulanır. */
function a_phonebook_import(): void
{
    $me = need_publisher();
    $items = arr('items');
    if (!$items) fail('Eklenecek satır yok.');
    if (count($items) > 2000) fail('Tek seferde en fazla 2000 satır eklenebilir.');
    $clean = [];
    foreach ($items as $it) {
        if (!is_array($it)) continue;
        $str = fn($k, $max) => is_scalar($it[$k] ?? null) ? mb_substr(trim((string)$it[$k]), 0, $max) : '';
        $name = $str('name', 120);
        $num = pb_number($str('number', 60));
        if (mb_strlen($name) < 2 || $num === '') continue;
        $clean[] = [$name, $num, $str('category', 60), $str('note', 200)];
    }
    if (!$clean) fail('Satırlarda ad ve numara bulunamadı.');
    if (s('scope', 10) === 'hastane' && function_exists('hdb') && hdb()) { $added = hpb_import($me, $clean, b('replace')); out(['added' => $added, 'skipped' => count($clean) - $added] + phonebook_payload()); }
    $pdo = db();
    $pdo->beginTransaction();
    try {
        if (b('replace')) q('DELETE FROM phonebook');
        $seen = [];
        foreach (all('SELECT name, number, category FROM phonebook') as $r) $seen[tr_lower($r['name']) . '|' . $r['number'] . '|' . tr_lower((string)$r['category'])] = 1;
        $sort = (int)val('SELECT COALESCE(MAX(sort), 0) FROM phonebook');
        $added = 0;
        foreach ($clean as [$name, $num, $cat, $note]) {
            $k = tr_lower($name) . '|' . $num . '|' . tr_lower($cat);
            if (isset($seen[$k])) continue;
            $seen[$k] = 1;
            q('INSERT INTO phonebook (name, number, category, note, pinned, updated_by, updated_at, sort) VALUES (?, ?, ?, ?, 0, ?, ?, ?)', [$name, $num, $cat, $note, $me['id'], now(), ++$sort]);
            $added++;
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    audit($me, 'phonebook.import', 'Telefon rehberi', $added . ' kayıt' . (b('replace') ? ' (liste yenilendi)' : ''));
    out(['added' => $added, 'skipped' => count($clean) - $added] + phonebook_payload());
}

/** Santral numarası: cep telefonundan dahiliyi aramak için önce santral aranır, sonra dahili tuşlanır. */
function a_phonebook_santral(): void
{
    $me = need_publisher();
    $v = s('santral', 60);
    $num = $v === '' ? '' : pb_number($v);
    if ($v !== '' && $num === '') fail('Santral numarası yalnızca rakam ve + ( ) - işaretleri içerebilir.');
    set_setting('pb_santral', $num);
    $dial = s('dial', 10);
    if (in_array($dial, ['auto', 'long', 'ask', 'manual'], true)) set_setting('pb_dial', $dial);
    audit($me, 'settings.save', 'Santral numarası', ($num ?: 'silindi') . ' · ' . setting('pb_dial', 'auto'));
    a_phonebook_list();
}

